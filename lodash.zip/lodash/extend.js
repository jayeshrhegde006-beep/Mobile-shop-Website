module.exports = require('./assignIn');
